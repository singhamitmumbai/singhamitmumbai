# Material Shortage Site-7 2026-11-01

_generated: 2026-10-31T15:36:22.786625+00:00_

## site
Site-7

## date
2026-11-01

## project_id
site-7

## shortages
- {'item': 'cement_bags', 'required': 100.0, 'available': 70.0, 'shortage': 30.0}
- {'item': 'steel_bars', 'required': 50.0, 'available': 50.0, 'shortage': 0.0}

## expected_deliveries

## source_note
deterministic inventory calculation; deliveries shown separately
