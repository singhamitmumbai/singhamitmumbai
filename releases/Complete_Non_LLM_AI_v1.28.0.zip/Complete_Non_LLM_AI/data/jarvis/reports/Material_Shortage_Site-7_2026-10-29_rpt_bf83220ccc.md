# Material Shortage Site-7 2026-10-29

_generated: 2026-10-28T07:19:01.079677+00:00_

## site
Site-7

## date
2026-10-29

## project_id
site-7

## shortages
- {'item': 'cement_bags', 'required': 100.0, 'available': 70.0, 'shortage': 30.0}
- {'item': 'steel_bars', 'required': 50.0, 'available': 50.0, 'shortage': 0.0}

## expected_deliveries

## source_note
deterministic inventory calculation; deliveries shown separately
